#!/usr/bin/env bash
# Run the fault-budget attack inside a memory-limited cgroup, modelling a
# validator whose consensus process is given LIMIT bytes.
#
#   sudo ./oom.sh 4294967296          unpatched -> OOM-killed (exit 137)
#   sudo ./oom.sh 4294967296 --fix    with the fix -> survives (exit 0)
#
# Requires a Linux host with a cgroup v1 memory controller and root.
set -uo pipefail

LIMIT="${1:-4294967296}"
FIX="${2:-}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/work/electroneum-sc"
CG=/sys/fs/cgroup/memory/etn-poc

[ -d "$SRC" ] || { echo "FATAL: run ./reproduce.sh first to fetch the target"; exit 1; }
[ -d /sys/fs/cgroup/memory ] || { echo "FATAL: no cgroup v1 memory controller at /sys/fs/cgroup/memory"; exit 1; }
[ "$(id -u)" = "0" ] || { echo "FATAL: needs root to create a cgroup"; exit 1; }

cd "$SRC"
git checkout --quiet -- consensus/istanbul/core/backlog.go 2>/dev/null || true
if [ "$FIX" = "--fix" ]; then
  echo ">>> applying retention-accounting.patch"
  git apply "$HERE/retention-accounting.patch"
fi

BIN=$(mktemp /tmp/etn-core-test.XXXXXX)
echo ">>> building test binary"
go test -c -o "$BIN" ./consensus/istanbul/core/ || exit 1
git checkout --quiet -- consensus/istanbul/core/backlog.go 2>/dev/null || true

mkdir -p "$CG"
echo "$LIMIT" > "$CG/memory.limit_in_bytes"
echo 0 > "$CG/memory.swappiness" 2>/dev/null || true
echo 0 > "$CG/memory.failcnt" 2>/dev/null || true

echo ">>> memory limit: $(( LIMIT / 1048576 )) MiB"
echo ">>> running TestE2E_WithinByzantineFaultBudget inside the cgroup"
( echo $BASHPID > "$CG/tasks"; exec "$BIN" -test.run TestE2E_WithinByzantineFaultBudget -test.v -test.timeout 25m )
RC=$?

echo
echo "EXIT=$RC"
echo "cgroup memory.failcnt   : $(cat "$CG/memory.failcnt" 2>/dev/null)"
echo "cgroup memory.max_usage : $(( $(cat "$CG/memory.max_usage_in_bytes" 2>/dev/null || echo 0) / 1048576 )) MiB"
rm -f "$BIN"
if [ "$RC" = "137" ]; then
  echo ">>> OOM-KILLED. f Byzantine validators killed the node at $(( LIMIT / 1048576 )) MiB."
elif [ "$RC" = "0" ]; then
  echo ">>> survived."
fi
exit 0
