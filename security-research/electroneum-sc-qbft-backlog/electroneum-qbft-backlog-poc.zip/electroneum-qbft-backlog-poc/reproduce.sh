#!/usr/bin/env bash
# Reproduce: QBFT backlog byte budget is charged in encoded wire bytes but
# retains the decoded object graph (electroneum-sc).
#
#   ./reproduce.sh           run the proof (needs ~2 GB RAM, ~5 min)
#   ./reproduce.sh --full    also run the fault-budget test (needs ~8 GB RAM)
#   ./reproduce.sh --unauth  run the unauthenticated-peer escalation (report 2)
#   ./reproduce.sh --fix     re-run everything with the candidate fix applied
#
# For the OOM proof (report 1, step 7) see ./oom.sh -- it needs root and a
# cgroup v1 memory controller.
#
# Everything happens in ./work/. Nothing outside this directory is touched.
# No network target is contacted: the only network access is `git clone`.

set -euo pipefail

COMMIT=17c6ffe
REPO=https://github.com/electroneum/electroneum-sc.git
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="$HERE/work"
SRC="$WORK/electroneum-sc"

FULL=0; FIX=0; UNAUTH=0
for a in "$@"; do
  case "$a" in
    --full)   FULL=1 ;;
    --fix)    FIX=1 ;;
    --unauth) UNAUTH=1 ;;
    *) echo "unknown option: $a"; exit 2 ;;
  esac
done

hr() { printf '%s\n' "------------------------------------------------------------"; }
say() { printf '\n>>> %s\n' "$*"; }

# ---- preflight -------------------------------------------------------------
command -v go   >/dev/null || { echo "FATAL: go is not installed (need 1.19+)"; exit 1; }
command -v git  >/dev/null || { echo "FATAL: git is not installed"; exit 1; }

GOVER=$(go version | awk '{print $3}')
say "toolchain: $GOVER"

MEM_MB=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo 2>/dev/null || echo 0)
if [ "$MEM_MB" -gt 0 ]; then
  say "available memory: ${MEM_MB} MiB"
  if [ "$FULL" = "1" ] && [ "$MEM_MB" -lt 8000 ]; then
    echo "WARNING: --full wants ~8 GB available; you have ${MEM_MB} MiB."
    echo "         The fault-budget test may be OOM-killed. Continuing anyway."
  elif [ "$MEM_MB" -lt 2000 ]; then
    echo "WARNING: the core proof wants ~2 GB available; you have ${MEM_MB} MiB."
  fi
fi

# ---- fetch the target at a pinned commit -----------------------------------
mkdir -p "$WORK"
if [ ! -d "$SRC/.git" ]; then
  say "cloning electroneum-sc (this is the only network access)"
  git clone --quiet "$REPO" "$SRC"
fi
git -C "$SRC" checkout --quiet "$COMMIT"
say "target pinned at $(git -C "$SRC" rev-parse --short HEAD) — $(git -C "$SRC" log -1 --format=%s)"

# ---- reset to a known state, then install the PoC --------------------------
git -C "$SRC" checkout --quiet -- . 2>/dev/null || true
rm -rf "$SRC/hunt"
cp -r "$HERE/poc/hunt"     "$SRC/hunt"
cp "$HERE/poc/core/"*.go    "$SRC/consensus/istanbul/core/"
cp "$HERE/poc/backend/"*.go "$SRC/consensus/istanbul/backend/"

if [ "$FIX" = "1" ]; then
  say "applying the candidate fix (retention-accounting.patch)"
  git -C "$SRC" apply "$HERE/retention-accounting.patch"
fi

cd "$SRC"
say "building (first run downloads Go modules)"
go build ./consensus/... >/dev/null

# ---- 1. the amplification primitive ----------------------------------------
hr; say "STEP 1  Amplification of the payload engine's primitives"
hr
go run ./hunt/cmd/amp

# ---- 2. end-to-end through the real message ingress ------------------------
hr; say "STEP 2  Signed PRE-PREPARE through the real ingress (+ negative control)"
hr
go test ./consensus/istanbul/core/ -run 'TestE2E_SignedPreprepareAmplification|TestE2E_ForgedSignatureIsRejected' \
  -v -timeout 20m 2>&1 | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true

# ---- 3. full stack: p2p frame into a live node -----------------------------
hr; say "STEP 3  Full stack — p2p frames into a live QBFT node via Backend.HandleMsg"
hr
go test ./consensus/istanbul/backend/ -run 'TestE2E_FullStack' \
  -v -timeout 20m 2>&1 | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true

# ---- 4. scaled to the Byzantine fault budget -------------------------------
if [ "$FULL" = "1" ]; then
  hr; say "STEP 4  Scaled to f = (N-1)/3 Byzantine validators (N=13, f=4)"
  hr
  go test ./consensus/istanbul/core/ -run 'TestE2E_WithinByzantineFaultBudget' \
    -v -timeout 30m 2>&1 | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true
else
  hr; say "STEP 4  skipped (pass --full to run the fault-budget test; needs ~8 GB)"
  hr
fi

# ---- 4b. unauthenticated-peer escalation (report 2) ------------------------
if [ "$UNAUTH" = "1" ]; then
  hr; say "STEP A  What one unauthenticated frame costs before any auth check"
  hr
  go test ./consensus/istanbul/backend/ -run 'TestUnauth_DecodeCostBeforeAnyAuthCheck' \
    -v -timeout 20m 2>&1 | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true

  hr; say "STEP B  Consensus ingress stall from a non-validator peer"
  hr
  go test ./consensus/istanbul/backend/ -run 'TestUnauth_StallsConsensusIngress' \
    -v -timeout 30m 2>&1 | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true

  hr; say "STEP C  Block production degradation"
  hr
  go test ./consensus/istanbul/backend/ -run 'TestUnauth_DegradesBlockProduction' \
    -v -timeout 30m 2>&1 | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true

  hr; say "STEP D  ROUND-CHANGE carries the same payload"
  hr
  go test ./consensus/istanbul/backend/ -run 'TestUnauth_RoundChangeAmplifiesToo' \
    -v -timeout 20m 2>&1 | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true

  hr; say "STEP E  Multiple keyless peers vs the QBFT round timeout"
  hr
  go test ./consensus/istanbul/backend/ -run 'TestUnauth_MultiPeerCrossesRoundTimeout' \
    -v -timeout 30m 2>&1 | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true
fi

# ---- 5. no regressions -----------------------------------------------------
hr; say "STEP 5  Upstream consensus/istanbul suite (PoC tests excluded)"
hr
# -skip removes this PoC's own tests, which fail on purpose when the bug is
# present. What remains is the project's own suite: it must stay green both
# unpatched and with the fix applied.
go test ./consensus/istanbul/... -skip 'TestE2E_|TestBacklogByteBudget' -timeout 30m 2>&1   | grep -E '^(ok|FAIL|---)' || true

hr
if [ "$FIX" = "1" ]; then
  cat <<'EOF'

RESULT (fix applied)
  The amplifying payloads are no longer admitted to the backlog. The E2E tests
  report [MITIGATED] and skip, the full-stack resident heap drops to ~0 MiB, and
  the upstream consensus/istanbul suite still passes.
EOF
else
  cat <<'EOF'

RESULT (unpatched — this is the bug)
  A single validator sends 32.00 MiB of signed PRE-PREPARE frames, which is
  exactly its per-sender backlog budget. Every admission check passes. The node
  retains ~1231 MiB of heap for them: x38.5 more than the budget it was charged.

  With --full: 4 Byzantine validators (= f, the faults QBFT already promises to
  survive) force ~4926 MiB resident while the global byte budget reports only
  128 MiB of 512 MiB used.

  Re-run with --fix to see the same payloads rejected.
  Run ./oom.sh (as root) for the OOM kill, and --unauth for the unauthenticated
  consensus-stall escalation.
EOF
fi
hr
