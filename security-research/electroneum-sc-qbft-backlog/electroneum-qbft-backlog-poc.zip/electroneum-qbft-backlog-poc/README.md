# QBFT backlog byte budget is charged in the wrong unit — reproduction package

**Target:** electroneum-sc, pinned at commit `17c6ffe`
**Component:** `consensus/istanbul/core/backlog.go`
**Effect:** one validator turns 32 MiB of wire traffic into ~1.2 GB of resident heap on every peer

## Run it

```bash
./reproduce.sh            # the proof            ~5 min,  ~2 GB RAM
./reproduce.sh --full     # + fault-budget scale ~8 min,  ~8 GB RAM
./reproduce.sh --fix      # same, with the candidate fix applied
```

Requires `go` (1.19+) and `git`. Everything is written to `./work/`; nothing
outside this directory is touched. The only network access is `git clone` of the
public repository — **no host belonging to Electroneum or anyone else is
contacted, and no chain state or production system is involved.** The whole thing
runs against a local, in-memory test chain.

## What each step shows

| Step | What runs | What it proves |
|---|---|---|
| 1 | `hunt/cmd/amp` | The primitive: a minimal legacy transaction is 10 wire bytes and ~386 bytes of resident heap (x38.7). |
| 2 | `TestE2E_SignedPreprepareAmplification` | The full ingress — decode, ecrecover, view check, backlog admission — with a genuine validator signature. 32 MiB charged, ~1231 MiB resident. Ships a **negative control** (`TestE2E_ForgedSignatureIsRejected`) proving the signature check really runs. |
| 3 | `TestE2E_FullStack_HandleMsgAmplification` | A live QBFT node on a real chain, driven only through `Backend.HandleMsg` with p2p frames. Same result. |
| 4 | `TestE2E_WithinByzantineFaultBudget` | `f = (N-1)/3` faulty validators — the faults QBFT already promises to survive — force ~4926 MiB resident while the global budget reports 128 MiB of 512 MiB used. |
| 5 | upstream suite with the PoC tests excluded | The project's own suite stays green — both with the PoC installed and with the fix applied. |

The PoC tests **fail on purpose** when the bug is present: the failure message is
the finding. With `--fix` they report `[MITIGATED]` and skip.

## Layout

```
reproduce.sh                  one-command driver
retention-accounting.patch    candidate fix for consensus/istanbul/core/backlog.go
poc/hunt/                     payload engine (RLP builder + genome + amplification scorer)
poc/core/                     PoC tests for package consensus/istanbul/core
poc/backend/                  full-stack PoC test for package consensus/istanbul/backend
work/                         created on first run: the cloned target
```

## The payload engine

`poc/hunt/` builds QBFT wire messages byte-by-byte rather than encoding Go
structs, so it can emit the *smallest legal* encoding of a structure the decoder
will still materialise in full. `Genome` parameterises a message (transaction
encoding, transaction count, uncles, justification entries); `SigningPayload()`
reproduces `Preprepare.EncodePayloadForSigning` byte-for-byte so the message can
be signed with a real validator key and survive `verifySignatures`.

`hunt/cmd/amp` scores each transaction encoding by measured
decoded-heap-per-encoded-byte. Minimal legacy transactions win at x38.7.

## Note on the tests being deliberately red

Steps 2–4 exit non-zero when unpatched. That is the intended signal, not a broken
harness — each test asserts that resident heap stays within the documented budget,
and that assertion is what fails. `reproduce.sh` swallows the non-zero exit so the
whole run completes and prints all five steps.
