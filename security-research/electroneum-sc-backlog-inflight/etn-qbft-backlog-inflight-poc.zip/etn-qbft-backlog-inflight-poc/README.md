# QBFT backlog budget stops counting a message at pop, not at release

**Target:** electroneum-sc, pinned at commit `17c6ffe`
**Component:** `consensus/istanbul/core/backlog.go` (`processBacklog`)
**Effect:** one sender holds twice its per-sender byte budget, because the
drained batch is still resident but charged to nobody.

## Run it

```bash
./reproduce.sh          # the proof             ~2 min, ~200 MB RAM
./reproduce.sh --fix    # same, with the candidate fix applied
```

Needs `go` (1.19+) and `git`. Everything lands in `./work/`. The only network
access is `git clone` of the public repo — no Electroneum host is contacted and no
chain state is used.

## The PoC test is supposed to FAIL

Unpatched it goes red, and the failure message is the finding:

```
BUDGET STOPS COUNTING TOO EARLY: 64.05 MiB resident for one sender whose
per-sender budget is 32 MiB. The drained batch is still held by 8 blocked
handoff goroutines but is charged to nobody.
```

With `--fix` it reports `[MITIGATED]` and skips.

## No amplification involved

The payloads are flat `Header.Extra` bytes built with the project's own
`makeFuturePreprepare` helper, so encoded size and resident size are 1:1 — the
table shows 32.00 MiB charged against 32.04 MiB resident. This is about *when*
the budget stops counting, not about how much a decoded message costs. It
reproduces with no amplifying payload at all.

## What each step shows

| Step | What runs | What it proves |
|---|---|---|
| 1 | `TestBacklogAccounting_InFlightUncharged` | Fill the per-sender budget, drain it with `processBacklog`, and the counters read zero while the heap is unchanged and 8 goroutines sit blocked on the unbuffered mux. The same sender is then re-admitted for the full budget, putting resident memory at 2x. |
| 2 | upstream `consensus/istanbul/...` suite, PoC excluded | The fix causes no regressions. |
| 3 | `TestProcessBacklog_*` and `TestAddToBacklog_*` by name | The project's own backlog accounting tests still pass with the fix, including `TestProcessBacklog_ByteAccountingIsExact`. |

## Layout

```
reproduce.sh                          one-command driver
backlog-charge-until-consumed.patch   candidate fix
poc/inflight_accounting_test.go       -> consensus/istanbul/core/
work/                                 created on first run: the cloned target
```
