#!/usr/bin/env bash
# Reproduce: the QBFT backlog byte budget stops counting a message when it is
# popped, not when it is released, so a sender can re-fill its budget against
# memory that is still resident.
#
#   ./reproduce.sh         run the proof  (~2 min, ~200 MB RAM)
#   ./reproduce.sh --fix   re-run with the candidate fix applied
#
# Everything happens in ./work/. The only network access is `git clone` of the
# public repository. No Electroneum host is contacted and no chain state is used.

set -uo pipefail

COMMIT=17c6ffe
REPO=https://github.com/electroneum/electroneum-sc.git
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/work/electroneum-sc"
FIX=0
[ "${1:-}" = "--fix" ] && FIX=1

hr(){ printf '%s\n' "------------------------------------------------------------"; }
say(){ printf '\n>>> %s\n' "$*"; }

command -v go  >/dev/null || { echo "FATAL: go not installed (need 1.19+)"; exit 1; }
command -v git >/dev/null || { echo "FATAL: git not installed"; exit 1; }
say "toolchain: $(go version | awk '{print $3}')"

mkdir -p "$HERE/work"
if [ ! -d "$SRC/.git" ]; then
  say "cloning electroneum-sc (only network access in this script)"
  git clone --quiet "$REPO" "$SRC"
fi
git -C "$SRC" checkout --quiet "$COMMIT"
git -C "$SRC" checkout --quiet -- . 2>/dev/null || true
say "target pinned at $(git -C "$SRC" rev-parse --short HEAD) — $(git -C "$SRC" log -1 --format=%s)"

cp "$HERE/poc/inflight_accounting_test.go" "$SRC/consensus/istanbul/core/zz_inflight_accounting_test.go"

if [ "$FIX" = "1" ]; then
  say "applying backlog-charge-until-consumed.patch"
  git -C "$SRC" apply "$HERE/backlog-charge-until-consumed.patch" || { echo "patch failed"; exit 1; }
fi

cd "$SRC"
say "building (first run downloads Go modules)"
go build ./consensus/... >/dev/null || exit 1

hr; say "STEP 1  Fill the budget, drain it, watch the counters vs the heap"
hr
go test ./consensus/istanbul/core/ -run TestBacklogAccounting_InFlightUncharged \
  -v -timeout 10m 2>&1 | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true

hr; say "STEP 2  Upstream consensus/istanbul suite (PoC excluded)"
hr
go test ./consensus/istanbul/... -skip 'TestBacklogAccounting' -timeout 15m 2>&1 \
  | grep -E '^(ok|FAIL|---)' || true

hr; say "STEP 3  The project's own backlog accounting tests, by name"
hr
go test ./consensus/istanbul/core/ -run 'TestProcessBacklog_|TestAddToBacklog' \
  -v -timeout 5m 2>&1 | grep -E '^(--- |ok|FAIL)' || true

hr
if [ "$FIX" = "1" ]; then
cat <<'EOF'

RESULT (fix applied)
  The drained batch stays charged until handleEvents consumes it, so the sender
  is re-admitted 0/8 instead of 8/8 and resident memory stays at one budget
  instead of two. Steps 2 and 3 are still green, including the project's own
  TestProcessBacklog_ByteAccountingIsExact.
EOF
else
cat <<'EOF'

RESULT (unpatched — this is the bug)
  The PoC test FAILS, and that failure is the finding:

    after fill             charged 32.00 MiB   resident 32.04 MiB
    after processBacklog   charged  0.00 MiB   resident 32.01 MiB   (8 goroutines blocked)
    after re-fill          charged 32.00 MiB   resident 64.05 MiB   (8/8 re-admitted)

  The budget reports the memory as freed at pop. It has not been freed - it is
  held by the handoff goroutines, blocked on the unbuffered mux. One sender
  therefore holds twice its per-sender budget.

  Payloads here are flat Header.Extra bytes, so encoded size and resident size
  are 1:1. This is an accounting bug, not an amplification bug.

  Re-run with --fix to see it neutralised.
EOF
fi
hr
