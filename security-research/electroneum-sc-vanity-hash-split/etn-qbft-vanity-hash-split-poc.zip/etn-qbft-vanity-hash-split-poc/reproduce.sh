#!/usr/bin/env bash
# Reproduce: attacker-chosen VanityData selects which hashing rule Header.Hash()
# uses, so one block can be finalized under two different valid hashes.
#
#   ./reproduce.sh         run the proof   (~2 min, no special hardware)
#   ./reproduce.sh --fix   re-run with the candidate fix applied
#
# Everything happens in ./work/. The only network access is `git clone` of the
# public repository. No Electroneum host is contacted and no chain state is used.

set -uo pipefail

COMMIT=17c6ffe
REPO=https://github.com/electroneum/electroneum-sc.git
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/work/electroneum-sc"
FIX=0
[ "${1:-}" = "--fix" ] && FIX=1

hr(){ printf '%s\n' "------------------------------------------------------------"; }
say(){ printf '\n>>> %s\n' "$*"; }

command -v go  >/dev/null || { echo "FATAL: go not installed (need 1.19+)"; exit 1; }
command -v git >/dev/null || { echo "FATAL: git not installed"; exit 1; }
say "toolchain: $(go version | awk '{print $3}')"

mkdir -p "$HERE/work"
if [ ! -d "$SRC/.git" ]; then
  say "cloning electroneum-sc (only network access in this script)"
  git clone --quiet "$REPO" "$SRC"
fi
git -C "$SRC" checkout --quiet "$COMMIT"
git -C "$SRC" checkout --quiet -- . 2>/dev/null || true
say "target pinned at $(git -C "$SRC" rev-parse --short HEAD) — $(git -C "$SRC" log -1 --format=%s)"

cp "$HERE/poc/types_vanity_split_test.go"  "$SRC/core/types/zz_vanity_split_test.go"
cp "$HERE/poc/engine_vanity_split_test.go" "$SRC/consensus/istanbul/engine/zz_vanity_split_test.go"

if [ "$FIX" = "1" ]; then
  say "applying filtered-header-prefer-qbft.patch"
  git -C "$SRC" apply "$HERE/filtered-header-prefer-qbft.patch" || { echo "patch failed"; exit 1; }
fi

cd "$SRC"
say "building (first run downloads Go modules)"
go build ./core/... ./consensus/... >/dev/null || exit 1

hr; say "STEP 1  VanityData decides which filter Header.Hash() uses"
hr
go test ./core/types/ -run TestVanityData_FlipsHashFilter -v -timeout 10m 2>&1 \
  | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true

hr; say "STEP 2  Real validator keys, real committed seals, both variants verified"
hr
go test ./consensus/istanbul/engine/ -run TestVanitySplit_BothVariantsVerify -v -timeout 10m 2>&1 \
  | grep -vE '^(=== RUN|=== CONT|=== PAUSE)' || true

hr; say "STEP 3  Upstream suite (PoC tests excluded) — the fix must not regress it"
hr
go test ./core/types/ ./consensus/istanbul/... -skip 'TestVanity' -timeout 20m 2>&1 \
  | grep -E '^(ok|FAIL|---)' || true

hr
if [ "$FIX" = "1" ]; then
cat <<'EOF'

RESULT (fix applied)
  Both PoC tests report [MITIGATED] and skip: every variant of the block now
  hashes identically, because FilteredHeader no longer lets the extra-data
  contents choose the hashing rule. The upstream suite above is still green.
EOF
else
cat <<'EOF'

RESULT (unpatched — this is the bug)
  Both PoC tests FAIL. That failure is the finding, not a broken harness:

    STEP 1  the same header hashes three different ways depending on a value
            the proposer chooses (its own VanityData), while the QBFT rule says
            all three must hash the same.

    STEP 2  two variants of one block, carrying committed seals signed by real
            validator keys over a byte-identical seal payload, BOTH pass
            verifyCommittedSeals and have DIFFERENT block hashes.

  Re-run with --fix to see both neutralised.
EOF
fi
hr
