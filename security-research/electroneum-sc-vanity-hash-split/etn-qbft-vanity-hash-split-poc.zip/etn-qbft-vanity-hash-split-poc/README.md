# One block, two valid hashes — QBFT vanity-controlled hash filter

**Target:** electroneum-sc, pinned at commit `17c6ffe`
**Component:** `core/types/istanbul.go` (`FilteredHeader`)
**Effect:** a proposer that chooses its own `VanityData` decides which hashing
rule `Header.Hash()` applies, and can finalize one block under two different
hashes that both carry a valid 2F+1 committed-seal quorum.

## Run it

```bash
./reproduce.sh          # the proof        ~2 min
./reproduce.sh --fix    # same, with the candidate fix applied
```

Needs `go` (1.19+) and `git`. Everything lands in `./work/`. The only network
access is `git clone` of the public repo — **no Electroneum host is contacted and
no chain state is touched.** Both tests run against local in-memory structures.

## The PoC tests are supposed to FAIL

Unpatched, both tests go red, and the failure message *is* the finding:

```
SPLIT: seal count changes Header.Hash() (994e69a91220f52e vs f9ed7088e6b647b3)
       while the seal payload is identical
CONSENSUS SPLIT: one block, two valid hashes. variant A (3 seals) and
       variant B (4 seals) both pass verifyCommittedSeals against the same
       seal payload
```

With `--fix` they report `[MITIGATED]` and skip. One line of step 1's output
still reads `legacy decode SUCCEEDS` after the fix — that is expected and not a
failure. The fix does not stop the legacy decode from parsing; it stops
`FilteredHeader` from acting on it. The three identical hashes on the next lines
are what matters. Step 3 runs the project's own
suite with the PoC excluded, so you can see the fix does not regress anything.

## What each step shows

| Step | What runs | What it proves |
|---|---|---|
| 1 | `TestVanityData_FlipsHashFilter` (`core/types`) | A 32-byte vanity takes the QBFT filter; a crafted 400-byte vanity takes the legacy filter. Under the legacy filter, `Round` and the committed-seal count both change `Header.Hash()`, while `QBFTHashWithRoundNumber` — what the seals actually sign — stays identical. |
| 2 | `TestVanitySplit_BothVariantsVerify` (`consensus/istanbul/engine`) | Real 4-validator set, committed seals signed with the validators' actual keys, run through the engine's own `verifyCommittedSeals`. Two variants of the same block both return `<nil>` and hash differently. |
| 3 | upstream suite, PoC excluded | The fix causes no regressions. |

## Layout

```
reproduce.sh                          one-command driver
filtered-header-prefer-qbft.patch     candidate fix for core/types/istanbul.go
poc/types_vanity_split_test.go        -> core/types/
poc/engine_vanity_split_test.go       -> consensus/istanbul/engine/
work/                                 created on first run: the cloned target
```

## About the craft

The PoC does not search for a working vanity — it computes the offsets. Given a
vanity length it derives where `Extra[32:]` lands inside the vanity, then writes a
fake legacy `IstanbulExtra` header there whose declared lengths make the fake list
end exactly at the end of `Extra`, with the real `CommittedSeal` field consumed as
the fake struct's third field.

The check that the arithmetic is right is the `ExtractIstanbulExtra` assertion in
the caller — if any length is wrong, the legacy decode fails and the test stops
there. (An earlier draft also asserted `1+3+N+len(csEnc) == M` inside
`craftVanity`; that was a tautology, since both sides derive from the same probe
length, and it has been removed rather than left in looking like a real check.)

## Two vectors, only one of which is a second valid block

`Header.Hash()` changes with both the committed-seal count and the `Round` under
the crafted vanity. Only the **seal count** yields a second *valid* block.
Bumping the round also changes `Signers()`'s seal payload
(`PrepareCommittedSeal(header, extra.Round)`), so the original signatures stop
verifying. Step 2 asserts that explicitly — variant R must fail
`verifyCommittedSeals`, and the test fails if it ever passes. The round line is
kept because `Round` entering the block hash at all is a rule violation
(`QBFTFilteredHeaderWithRound` zeroes it precisely so it cannot), not because it
gives a second block.

## Post-FutureFork format

Step 1 also probes the 6-field `QBFTExtra` encoding used once `FutureFork`
activates (non-empty `ProposerSeal`). The craft is **structurally dead** there,
not merely mis-sized: the tail item becomes a byte string while `IstanbulExtra`'s
third field is `CommittedSeal [][]byte` and must be a list. There are only two
possible sizings and the test runs both — one leaves the 67-byte `ProposerSeal`
inside the fake list as a fourth element (`input list has too many elements`), the
other puts field three on the byte string (`expected input list for [][]uint8`).
No length choice rescues it.

That is why the filter reorder closes today's live 5-field format while the vanity
length check is the fix that holds across both.
